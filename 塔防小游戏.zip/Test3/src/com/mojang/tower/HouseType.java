// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HouseType.java
// Download by http://www.codefans.net
package com.mojang.tower;

import java.awt.image.BufferedImage;

// Referenced classes of package com.mojang.tower:
//            Bitmaps

public class HouseType
{

    private HouseType(int image, String name, int radius, int wood, int rock, int food)
    {
        acceptResource = -1;
        this.image = image;
        this.name = name;
        this.radius = radius;
        this.wood = wood;
        this.rock = rock;
        this.food = food;
        houseTypes[id++] = this;
    }

    private HouseType setAcceptsResource(int acceptResource)
    {
        this.acceptResource = acceptResource;
        return this;
    }

    public BufferedImage getImage(Bitmaps bitmaps)
    {
        return bitmaps.houses[image % 2 + 1][image / 2];
    }

    public String getString()
    {
        String res = (new StringBuilder(String.valueOf(name))).append(" [").toString();
        if(wood > 0)
            res = (new StringBuilder(String.valueOf(res))).append(" wood:").append(wood).toString();
        if(rock > 0)
            res = (new StringBuilder(String.valueOf(res))).append(" rock:").append(rock).toString();
        if(food > 0)
            res = (new StringBuilder(String.valueOf(res))).append(" food:").append(food).toString();
        res = (new StringBuilder(String.valueOf(res))).append(" ]").toString();
        return res;
    }

    public String getDescription()
    {
        if(this == MASON)
            return "Gathers nearby stones, produces rock";
        if(this == WOODCUTTER)
            return "Cuts down nearby trees, produces wood";
        if(this == PLANTER)
            return "Plants new trees that can later be cut down";
        if(this == FARM)
            return "Plants crops that can later be harvested";
        if(this == WINDMILL)
            return "Gathers nearby grown crops, produces food";
        if(this == GUARDPOST)
            return "Peons and warriors generally stay near these";
        if(this == BARRACKS)
            return "Converts peons into warriors for 5 wood each";
        if(this == RESIDENCE)
            return "Produces peons for 5 food each";
        else
            return "**unknown**";
    }

    public static final HouseType houseTypes[] = new HouseType[8];
    public static final HouseType MASON = (new HouseType(1, "Mason", 10, 0, 15, 0)).setAcceptsResource(1);
    public static final HouseType WOODCUTTER = (new HouseType(2, "Woodcutter", 10, 15, 0, 0)).setAcceptsResource(0);
    public static final HouseType PLANTER = new HouseType(0, "Planter", 10, 30, 15, 10);
    public static final HouseType FARM = new HouseType(6, "Farmer", 10, 30, 30, 0);
    public static final HouseType WINDMILL = (new HouseType(7, "Miller", 8, 15, 15, 0)).setAcceptsResource(2);
    public static final HouseType GUARDPOST = new HouseType(5, "Guardpost", 3, 0, 30, 0);
    public static final HouseType BARRACKS = new HouseType(3, "Barracks", 10, 15, 50, 0);
    public static final HouseType RESIDENCE = new HouseType(4, "Residence", 10, 30, 30, 30);
    public final int image;
    public final int radius;
    public final String name;
    public final int wood;
    public final int rock;
    public final int food;
    public int acceptResource;
    private static int id = 0;

}
