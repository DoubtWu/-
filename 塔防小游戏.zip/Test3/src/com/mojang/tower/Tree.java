// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Tree.java

package com.mojang.tower;

import java.awt.Graphics2D;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Entity, Island, Bitmaps

public class Tree extends Entity
{

    public Tree(double x, double y, int age)
    {
        super(x, y, 4D);
        stamina = 0;
        yield = 0;
        yield = stamina = this.age = age;
        spreadDelay = random.nextInt(30000);
    }

    public void tick()
    {
        if(age < 4800)
        {
            age++;
            stamina++;
            yield++;
        } else
        if(spreadDelay-- <= 0)
        {
            double xp = x + random.nextGaussian() * 8D;
            double yp = y + random.nextGaussian() * 8D;
            Tree tree = new Tree(xp, yp, 0);
            if(island.isFree(tree.x, tree.y, tree.r))
                island.addEntity(tree);
            spreadDelay = 30000;
        }
    }

    public void render(Graphics2D g, double alpha)
    {
        int x = (int)(xr - 4D);
        int y = -(int)(yr / 2D + 16D);
        g.drawImage(bitmaps.trees[15 - age / 320], x, y, null);
    }

    public void cut()
    {
        alive = false;
    }

    public boolean gatherResource(int resourceId)
    {
        stamina -= 64;
        if(stamina <= 0)
        {
            alive = false;
            return true;
        } else
        {
            return false;
        }
    }

    public int getAge()
    {
        return age / 320;
    }

    public boolean givesResource(int resourceId)
    {
        return getAge() > 6 && resourceId == 0;
    }

    public static final int GROW_SPEED = 320;
    public static final int SPREAD_INTERVAL = 30000;
    private int age;
    private int spreadDelay;
    private int stamina;
    private int yield;
}
