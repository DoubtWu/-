// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   InfoPuff.java

package com.mojang.tower;

import java.awt.Graphics2D;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Entity, Bitmaps

public class InfoPuff extends Entity
{

    public void updatePos(double sin, double cos, double alpha)
    {
        super.updatePos(sin, cos, alpha);
        yr -= 2D;
    }

    public InfoPuff(double x, double y, int image)
    {
        super(x, y, -1D);
        z = 0.0D;
        this.image = image;
        z = 12D;
        za = 0.29999999999999999D;
        life = 0;
        lifeTime = 80 + random.nextInt(60);
    }

    public void tick()
    {
        xa *= 0.98999999999999999D;
        ya *= 0.98999999999999999D;
        za *= 0.98999999999999999D;
        x += xa;
        y += ya;
        z += za;
        if(life++ == lifeTime)
            alive = false;
    }

    public void render(Graphics2D g, double alpha)
    {
        int x = (int)(xr - 8D);
        int y = -(int)(yr / 2D + 4D + (z + za * alpha));
        g.drawImage(bitmaps.infoPuffs[image], x, y, null);
    }

    public double xa;
    public double ya;
    public double za;
    public double z;
    public int life;
    public int lifeTime;
    private int image;
}
