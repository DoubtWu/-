// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Rock.java
// Download by http://www.codefans.net
package com.mojang.tower;

import java.awt.Graphics2D;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Entity, Bitmaps

public class Rock extends Entity
{

    public Rock(double x, double y)
    {
        super(x, y, 5D);
        type = 0;
        stamina = 5000;
        life = 16;
        type = random.nextInt(4);
    }

    public void tick()
    {
    }

    public void render(Graphics2D g, double alpha)
    {
        int x = (int)(xr - 4D);
        int y = -(int)((yr / 2D + 8D) - 2D);
        g.drawImage(bitmaps.rocks[type], x, y, null);
    }

    public boolean gatherResource(int resourceId)
    {
        stamina -= 64;
        if(stamina <= 0)
        {
            stamina += 5000;
            if(--life == 0)
                alive = false;
            return true;
        } else
        {
            return false;
        }
    }

    public boolean givesResource(int resourceId)
    {
        return resourceId == 1;
    }

    private int type;
    private int stamina;
    private int life;
}
