// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Peon.java

package com.mojang.tower;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Entity, Island, Monster, Sounds, 
//            Job, Bitmaps, InfoPuff, Sound, 
//            TargetFilter

public class Peon extends Entity
{

    public Peon(double x, double y, int type)
    {
        super(x, y, 1.0D);
        rot = 0.0D;
        moveTick = 0.0D;
        wanderTime = 0;
        hp = 100;
        maxHp = 100;
        xp = 0;
        nextLevel = 1;
        level = 0;
        this.type = type;
        rot = random.nextDouble() * 3.1415926535897931D * 2D;
        moveTick = random.nextInt(12);
    }

    public void init(Island island, Bitmaps bitmaps)
    {
        super.init(island, bitmaps);
        island.population++;
    }

    public void fight(Monster monster)
    {
        if(job == null && (type == 1 || random.nextInt(10) == 0))
            setJob(new Job.Hunt(monster));
        if(type == 0)
        {
            monster.fight(this);
            if((hp -= 4) <= 0)
                die();
        } else
        {
            monster.fight(this);
            if(--hp <= 0)
                die();
        }
    }

    public void die()
    {
        Sounds.play(new Sound.Death());
        island.population--;
        if(type == 1)
            island.warriorPopulation--;
        alive = false;
    }

    public void setJob(Job job)
    {
        this.job = job;
        if(job != null)
            job.init(island, this);
    }

    public void tick()
    {
        if(job != null)
            job.tick();
        if(type == 1 || job == null)
        {
            for(int i = 0; i < 15 && (job == null || (job instanceof Job.Goto)); i++)
            {
                TargetFilter monsterFilter = new TargetFilter() {

                    public boolean accepts(Entity e)
                    {
                        return e.isAlive() && (e instanceof Monster);
                    }

               
                }
;
                Entity e = type != 0 ? getRandomTarget(70D, 80D, monsterFilter) : getRandomTarget(30D, 15D, monsterFilter);
                if(e instanceof Monster)
                    setJob(new Job.Hunt((Monster)e));
            }

        }
        if(hp < maxHp && random.nextInt(5) == 0)
            hp++;
        double speed = 1.0D;
        if(wanderTime == 0 && job != null && job.hasTarget())
        {
            double xd = job.xTarget - x;
            double yd = job.yTarget - y;
            double rd = job.targetDistance + r;
            if(xd * xd + yd * yd < rd * rd)
            {
                job.arrived();
                speed = 0.0D;
            }
            rot = Math.atan2(yd, xd);
        } else
        {
            rot += (random.nextDouble() - 0.5D) * random.nextDouble() * 2D;
        }
        if(wanderTime > 0)
            wanderTime--;
        speed += (double)level * 0.10000000000000001D;
        double xt = x + Math.cos(rot) * 0.40000000000000002D * speed;
        double yt = y + Math.sin(rot) * 0.40000000000000002D * speed;
        if(island.isFree(xt, yt, r, this))
        {
            x = xt;
            y = yt;
        } else
        {
            if(job != null)
            {
                Entity collided = island.getEntityAt(xt, yt, r, null, this);
                if(collided != null)
                    job.collide(collided);
                else
                    job.cantReach();
            }
            rot = random.nextDouble() * 3.1415926535897931D * 2D;
            wanderTime = random.nextInt(30) + 3;
        }
        moveTick += speed;
        super.tick();
    }

    public void render(Graphics2D g, double alpha)
    {
        int rotStep = (int)Math.floor(((rot - island.rot) * 4D) / 6.2831853071795862D + 0.5D);
        int animStep = animSteps[(int)(moveTick / 4D) & 3];
        int x = (int)(xr - 4D);
        int y = -(int)(yr / 2D + 8D);
        int carrying = -1;
        if(job != null)
            carrying = job.getCarried();
        if(carrying >= 0)
        {
            g.drawImage(bitmaps.peons[2][animDirs[rotStep & 3] * 3 + animStep], x, y, null);
            g.drawImage(bitmaps.carriedResources[carrying], x, y - 3, null);
        } else
        {
            g.drawImage(bitmaps.peons[type][animDirs[rotStep & 3] * 3 + animStep], x, y, null);
        }
        if(hp < maxHp)
        {
            g.setColor(Color.BLACK);
            g.fillRect(x + 2, y - 2, 4, 1);
            g.setColor(Color.RED);
            g.fillRect(x + 2, y - 2, (hp * 4) / maxHp, 1);
        }
    }

    public void setType(int i)
    {
        type = i;
        hp = maxHp = type != 0 ? 100 : 20;
    }

    public void addXp()
    {
        xp++;
        if(xp == nextLevel)
        {
            nextLevel = nextLevel * 2 + 1;
            island.addEntity(new InfoPuff(x, y, 0));
            hp += 10;
            maxHp += 10;
            level++;
            Sounds.play(new Sound.Ding());
        }
    }

    private static final int animSteps[] = {
        0, 1, 0, 2
    };
    private static final int animDirs[] = {
        2, 0, 3, 1
    };
    public double rot;
    public double moveTick;
    public int type;
    private int wanderTime;
    protected Job job;
    protected double xTarget;
    protected double yTarget;
    private int hp;
    private int maxHp;
    private int xp;
    private int nextLevel;
    private int level;

}
