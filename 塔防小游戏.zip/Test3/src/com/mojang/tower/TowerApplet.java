// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TowerApplet.java

package com.mojang.tower;

import java.applet.Applet;
import java.awt.BorderLayout;

// Referenced classes of package com.mojang.tower:
//            TowerComponent

public class TowerApplet extends Applet
{

    public TowerApplet()
    {
    	
    }

    public void init()
    {
    	setSize(800, 480);
        tower = new TowerComponent(getWidth() / 2, getHeight() / 2);
        setLayout(new BorderLayout());
        add(tower, "Center");
    }

    public void start()
    {
        tower.unpause();
    }

    public void stop()
    {
        tower.pause();
    }

    public void destroy()
    {
        tower.stop();
    }

    private static final long serialVersionUID = 1L;
    private TowerComponent tower;
}
