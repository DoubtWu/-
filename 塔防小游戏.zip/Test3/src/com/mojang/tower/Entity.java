// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Entity.java

package com.mojang.tower;

import java.awt.Graphics2D;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Island, Bitmaps, TargetFilter, Monster

public class Entity
    implements Comparable
{

    public Entity(double x, double y, double r)
    {
        random = new Random();
        alive = true;
        this.x = x;
        this.y = y;
        this.r = r;
    }

    public void updatePos(double sin, double cos, double alpha)
    {
        xr = x * cos + y * sin;
        yr = x * sin - y * cos;
    }

    public void init(Island island, Bitmaps bitmaps)
    {
        this.island = island;
        this.bitmaps = bitmaps;
    }

    public void tick()
    {
    }

    public boolean isAlive()
    {
        return alive;
    }

    public boolean collides(Entity e)
    {
        return collides(e.x, e.y, e.r);
    }

    public boolean collides(double ex, double ey, double er)
    {
        if(r < 0.0D)
            return false;
        double xd = x - ex;
        double yd = y - ey;
        return xd * xd + yd * yd < r * r + er * er;
    }

    public int compareTo(Entity s)
    {
        return Double.compare(s.yr, yr);
    }

    public void render(Graphics2D graphics2d, double d)
    {
    }

    public double distance(Entity e)
    {
        double xd = x - e.x;
        double yd = y - e.y;
        return xd * xd + yd * yd;
    }

    public boolean givesResource(int resourceId)
    {
        return false;
    }

    public boolean gatherResource(int resourceId)
    {
        return false;
    }

    public boolean acceptsResource(int resourceId)
    {
        return false;
    }

    public boolean submitResource(int resourceId)
    {
        return false;
    }

    public Entity getRandomTarget(double radius, double rnd, TargetFilter filter)
    {
        double xt = x + (random.nextDouble() * 2D - 1.0D) * rnd;
        double yt = y + (random.nextDouble() * 2D - 1.0D) * rnd;
        return island.getEntityAt(xt, yt, radius, filter);
    }

    public void setPos(double xp, double yp)
    {
        x = xp;
        y = yp;
    }

    public void fight(Monster monster1)
    {
    }

    public int compareTo(Object obj)
    {
        return compareTo((Entity)obj);
    }

    public double x;
    public double y;
    public double r;
    public double xr;
    public double yr;
    protected Island island;
    protected Bitmaps bitmaps;
    protected Random random;
    protected boolean alive;
}
