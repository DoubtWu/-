// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FarmPlot.java
// Download by http://www.codefans.net
package com.mojang.tower;

import java.awt.Graphics2D;

// Referenced classes of package com.mojang.tower:
//            Entity, Bitmaps

public class FarmPlot extends Entity
{

    public FarmPlot(double x, double y, int age)
    {
        super(x, y, 0.0D);
        stamina = 0;
        yield = 0;
        yield = stamina = this.age = age;
    }

    public void tick()
    {
        if(age < 1400)
        {
            age++;
            stamina++;
            yield++;
        }
    }

    public void render(Graphics2D g, double alpha)
    {
        int x = (int)(xr - 4D);
        int y = -(int)(yr / 2D + 5D);
        g.drawImage(bitmaps.farmPlots[7 - age / 200], x, y, null);
    }

    public void cut()
    {
        alive = false;
    }

    public boolean gatherResource(int resourceId)
    {
        stamina -= 64;
        if(stamina <= 0)
        {
            alive = false;
            return true;
        } else
        {
            return false;
        }
    }

    public int getAge()
    {
        return age / 200;
    }

    public boolean givesResource(int resourceId)
    {
        return getAge() > 6 && resourceId == 2;
    }

    public static final int GROW_SPEED = 200;
    private int age;
    private int stamina;
    private int yield;
}
