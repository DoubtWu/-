// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Island.java

package com.mojang.tower;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.WritableRaster;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Resources, Tower, House, HouseType, 
//            Peon, Rock, Tree, TowerComponent, 
//            Entity, TargetFilter, Sounds, Sound

public class Island
{

    public Island(TowerComponent tower, BufferedImage image)
    {
        entities = new ArrayList();
        random = new Random(8844L);
        resources = new Resources();
        population = 0;
        populationCap = 10;
        monsterPopulation = 0;
        warriorPopulation = 0;
        warriorPopulationCap = 0;
        this.tower = tower;
        this.image = image;
        pixels = ((DataBufferInt)image.getRaster().getDataBuffer()).getData();
        for(int i = 0; i < 1;)
        {
            double x = (random.nextDouble() * 256D - 128D) * 1.5D;
            double y = (random.nextDouble() * 256D - 128D) * 1.5D;
            Tower t = new Tower(x, y);
            if(isFree(t.x, t.y, t.r))
            {
                addEntity(t);
                i++;
            }
        }

        for(int i = 0; i < 7; i++)
        {
            double x = (random.nextDouble() * 256D - 128D) * 1.5D;
            double y = (random.nextDouble() * 256D - 128D) * 1.5D;
            addRocks(x, y);
        }

        for(int i = 0; i < 20; i++)
        {
            double x = (random.nextDouble() * 256D - 128D) * 1.5D;
            double y = (random.nextDouble() * 256D - 128D) * 1.5D;
            addForrest(x, y);
        }

        double xStart = 40D;
        double yStart = -120D;
        House house = new House(xStart, yStart, HouseType.GUARDPOST);
        house.complete();
        addEntity(house);
        for(int i = 0; i < 10;)
        {
            double x = xStart + (random.nextDouble() * 32D - 16D);
            double y = yStart + (random.nextDouble() * 32D - 16D);
            Peon peon = new Peon(x, y, 0);
            if(isFree(peon.x, peon.y, peon.r))
            {
                addEntity(peon);
                i++;
            }
        }

    }

    private void addRocks(double xo, double yo)
    {
        for(int i = 0; i < 100; i++)
        {
            double x = xo + random.nextGaussian() * 10D;
            double y = yo + random.nextGaussian() * 10D;
            Rock rock = new Rock(x, y);
            if(isFree(rock.x, rock.y, rock.r))
                addEntity(rock);
        }

    }

    private void addForrest(double xo, double yo)
    {
        for(int i = 0; i < 200; i++)
        {
            double x = xo + random.nextGaussian() * 20D;
            double y = yo + random.nextGaussian() * 20D;
            Tree tree = new Tree(x, y, random.nextInt(5120));
            if(isFree(tree.x, tree.y, tree.r))
                addEntity(tree);
        }

    }

    public void addEntity(Entity entity)
    {
        entity.init(this, tower.bitmaps);
        entities.add(entity);
        entity.tick();
    }

    public boolean isFree(double x, double y, double r)
    {
        return isFree(x, y, r, null);
    }

    public boolean isFree(double x, double y, double r, Entity source)
    {
        if(!isOnGround(x, y))
            return false;
        for(int i = 0; i < entities.size(); i++)
        {
            Entity e = (Entity)entities.get(i);
            if(e != source && e.collides(x, y, r))
                return false;
        }

        return true;
    }

    public Entity getEntityAt(double x, double y, double r, TargetFilter filter)
    {
        return getEntityAt(x, y, r, filter, null);
    }

    public Entity getEntityAt(double x, double y, double r, TargetFilter filter, 
            Entity exception)
    {
        double closest = 1000000D;
        Entity closestEntity = null;
        for(int i = 0; i < entities.size(); i++)
        {
            Entity e = (Entity)entities.get(i);
            if(e != exception && (filter == null || filter.accepts(e)) && e.collides(x, y, r))
            {
                double dist = (e.x - x) * (e.x - x) + (e.y - y) * (e.y - y);
                if(dist < closest)
                {
                    closest = dist;
                    closestEntity = e;
                }
            }
        }

        return closestEntity;
    }

    public void tick()
    {
        if(monsterPopulation < 0)
        {
            System.out.println("Monster population is less than 0!!");
            monsterPopulation = 0;
        }
        for(int i = 0; i < entities.size(); i++)
        {
            Entity entity = (Entity)entities.get(i);
            entity.tick();
            if(!entity.isAlive())
                entities.remove(i--);
        }

    }

    public boolean isOnGround(double x, double y)
    {
        x /= 1.5D;
        y /= 1.5D;
        int xp = (int)(x + 128D);
        int yp = (int)(y + 128D);
        if(xp < 0 || yp < 0 || xp >= 256 || yp >= 256)
            return false;
        return pixels[yp << 8 | xp] >>> 24 > 128;
    }

    public Entity getEntityAtMouse(double x, double y, TargetFilter filter)
    {
        x *= 0.5D;
        y *= -1D;
        double sin = Math.sin(rot);
        double cos = Math.cos(rot);
        double xp = x * cos + y * sin;
        double yp = x * sin - y * cos;
        return getEntityAt(xp, yp, 8D, filter);
    }

    public boolean canPlaceHouse(double x, double y, HouseType type)
    {
        if(resources.canAfford(type))
        {
            x *= 0.5D;
            y *= -1D;
            double sin = Math.sin(rot);
            double cos = Math.cos(rot);
            double xp = x * cos + y * sin;
            double yp = x * sin - y * cos;
            House house = new House(xp, yp, type);
            if(isFree(house.x, house.y, house.r))
                return true;
        }
        return false;
    }

    public void placeHouse(double x, double y, HouseType type)
    {
        if(resources.canAfford(type))
        {
            x *= 0.5D;
            y *= -1D;
            double sin = Math.sin(rot);
            double cos = Math.cos(rot);
            double xp = x * cos + y * sin;
            double yp = x * sin - y * cos;
            House house = new House(xp, yp, type);
            if(isFree(house.x, house.y, house.r))
            {
                Sounds.play(new Sound.Plant());
                addEntity(house);
                resources.charge(type);
            }
        }
    }

    public void win()
    {
        tower.win();
    }

    private TowerComponent tower;
    public BufferedImage image;
    private int pixels[];
    java.util.List entities;
    private Random random;
    public Resources resources;
    public double rot;
    public int population;
    public int populationCap;
    public int monsterPopulation;
    public int warriorPopulation;
    public int warriorPopulationCap;
}
