// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Resources.java

package com.mojang.tower;


// Referenced classes of package com.mojang.tower:
//            HouseType

public class Resources
{

    public Resources()
    {
        wood = 100;
        rock = 100;
        food = 100;
    }

    public void add(int resourceId, int count)
    {
        switch(resourceId)
        {
        case 0: // '\0'
            wood += count;
            break;

        case 1: // '\001'
            rock += count;
            break;

        case 2: // '\002'
            food += count;
            break;
        }
    }

    public void charge(HouseType type)
    {
        wood -= type.wood;
        rock -= type.rock;
        food -= type.food;
    }

    public boolean canAfford(HouseType type)
    {
        if(wood < type.wood)
            return false;
        if(rock < type.rock)
            return false;
        return food >= type.food;
    }

    public static final int WOOD = 0;
    public static final int ROCK = 1;
    public static final int FOOD = 2;
    public int wood;
    public int rock;
    public int food;
}
