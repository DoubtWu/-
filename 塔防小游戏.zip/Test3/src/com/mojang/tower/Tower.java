// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Tower.java

package com.mojang.tower;

import java.awt.Graphics2D;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Entity, Island, Monster, Bitmaps

public class Tower extends Entity
{

    public Tower(double x, double y)
    {
        super(x, y, 16D);
        h = 0;
        staminaPerLevel = 8192;
        stamina = staminaPerLevel;
        minMonsters = 3;
        h = 80;
    }

    public void tick()
    {
        if(random.nextInt(100) == 0 && island.monsterPopulation < minMonsters)
        {
            double xt = x + (random.nextDouble() * 2D - 1.0D) * (r + 5D);
            double yt = y + (random.nextDouble() * 2D - 1.0D) * (r + 5D);
            Monster monster = new Monster(xt, yt);
            if(island.isFree(monster.x, monster.y, monster.r))
                island.addEntity(monster);
        }
    }

    public void render(Graphics2D g, double alpha)
    {
        int x = (int)(xr - 16D);
        int y = -(int)(yr / 2D);
        for(int i = 0; i < h / 8; i++)
            g.drawImage(bitmaps.towerMid, x, y - 8 - i * 8, null);

        g.drawImage(bitmaps.towerMid, x, y - h - 1, null);
        g.drawImage(bitmaps.towerBot, x, y, null);
        g.drawImage(bitmaps.towerTop, x, y - h - 8, null);
    }

    public boolean gatherResource(int resourceId)
    {
        stamina -= 64;
        if(stamina <= 0)
        {
            for(int i = 0; i < 1;)
            {
                double xt = x + (random.nextDouble() * 2D - 1.0D) * (r + 5D);
                double yt = y + (random.nextDouble() * 2D - 1.0D) * (r + 5D);
                Monster monster = new Monster(xt, yt);
                if(island.isFree(monster.x, monster.y, monster.r))
                {
                    island.addEntity(monster);
                    i++;
                }
            }

            stamina += staminaPerLevel;
            if(h % 20 == 0)
                minMonsters++;
            if(--h <= 4)
            {
                island.win();
                alive = false;
            }
            return true;
        } else
        {
            return false;
        }
    }

    public boolean givesResource(int resourceId)
    {
        return resourceId == 1;
    }

    private static final boolean DEBUG = false;
    private int h;
    private int staminaPerLevel;
    private int stamina;
    private int minMonsters;
}
