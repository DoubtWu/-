// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Sound.java

package com.mojang.tower;

import java.util.Random;

public abstract class Sound
{
    public static class Death extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                double rate = 3000 - (((p * 100) / duration) * p) / duration;
                rate /= 2D;
                noise += (random.nextDouble() * 200D - 100D - noise) * 0.59999999999999998D;
                double smp2 = Math.sin((((double)p * rate) / 44100D) * 3.1415926535897931D * 2D) * 120D;
                double smp1 = noise;
                double smp = smp1 + ((smp2 - smp1) * (double)p) / (double)duration;
                buffer[i] += ((int)smp * (duration - p)) / duration;
                i++;
                p++;
            }

        }

        double noise;

        public Death()
        {
            super(250);
            noise = 0.0D;
        }
    }

    public static class Destroy extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                if(p % 60 == 0)
                    val = random.nextInt(256) - 128;
                buffer[i] += (((val * (duration - p)) / duration) * (duration - p)) / duration;
                i++;
                p++;
            }

        }

        int val;

        public Destroy()
        {
            super(1000);
            val = 0;
        }
    }

    public static class Ding extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                double rate = 2000 + (p * 1000) / duration;
                if(p < duration / 2)
                    rate = 5000D - rate;
                buffer[i] += ((int)(Math.sin((((double)p * rate) / 44100D) * 3.1415926535897931D * 2D) * 120D) * (duration - p)) / duration;
                i++;
                p++;
            }

        }

        public Ding()
        {
            super(200);
        }
    }

    public static class FinishBuilding extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                if(p % 11 == 0)
                    val = random.nextInt(100) - 50;
                buffer[i] += val;
                i++;
                p++;
            }

        }

        int val;

        public FinishBuilding()
        {
            super(50);
            val = 0;
        }
    }

    public static class Gather extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                if(p % 4 == 0)
                    val = random.nextInt(100) - 50;
                buffer[i] += val;
                i++;
                p++;
            }

        }

        int val;

        public Gather()
        {
            super(10);
            val = 0;
        }
    }

    public static class MonsterDeath extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                double rate = 1000 + (((p * 100) / duration) * p) / duration;
                rate /= 2D;
                noise += (random.nextDouble() * 200D - 100D - noise) * 0.80000000000000004D;
                double smp2 = Math.sin((((double)p * rate) / 44100D) * 3.1415926535897931D * 2D) * 120D;
                double smp1 = noise;
                double smp = smp1 + ((smp2 - smp1) * (double)p) / (double)duration;
                buffer[i] += ((int)smp * (duration - p)) / duration;
                i++;
                p++;
            }

        }

        double noise;

        public MonsterDeath()
        {
            super(250);
            noise = 0.0D;
        }
    }

    public static class Plant extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                if(p % 20 == 0)
                    val = random.nextInt(180) - 90;
                buffer[i] += (val * (duration - p)) / duration;
                i++;
                p++;
            }

        }

        int val;

        public Plant()
        {
            super(250);
            val = 0;
        }
    }

    public static class Select extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                buffer[i] += (((((i * 3000) / 44100) % 2) * 180 - 90) * (duration - p)) / duration;
                i++;
                p++;
            }

        }

        public Select()
        {
            super(10);
        }
    }

    public static class Spawn extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                int rate = 1000 + (((p * 2000) / duration) * p) / duration;
                buffer[i] += (((((((i * rate) / 44100) % 2) * 180 - 90) * (duration - p)) / duration) * (duration - p)) / duration / 2;
                i++;
                p++;
            }

        }

        public Spawn()
        {
            super(200);
        }
    }

    public static class SpawnWarrior extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                int rate = 800 - (((p * 200) / duration) * p) / duration;
                buffer[i] += (((((((i * rate) / 44100) % 2) * 180 - 90) * (duration - p)) / duration) * (duration - p)) / duration / 2;
                i++;
                p++;
            }

        }

        public SpawnWarrior()
        {
            super(400);
        }
    }

    public static class WinSound extends Sound
    {

        protected void fill(int buffer[], int len)
        {
            for(int i = 0; i < len;)
            {
                int d = duration / 5;
                double volume = 1.0D - (double)(p % d) / (double)d;
                double rate = 440D * Math.pow(2D, (double)(p / d) / 6D);
                double tone = Math.sin((((double)p * rate) / 44100D) * 3.1415926535897931D * 2D) * 120D;
                buffer[i] += (int)(tone * volume);
                i++;
                p++;
            }

        }

        public WinSound()
        {
            super(1000);
        }
    }


    protected Sound(int ms)
    {
        p = 0;
        random = new Random();
        duration = (44100 * ms) / 1000;
    }

    public boolean read(int buffer[], int len)
    {
        if(p + len > duration)
            len = duration - p;
        fill(buffer, len);
        return p <= duration;
    }

    protected abstract void fill(int ai[], int i);

    protected int p;
    protected int duration;
    protected Random random;
}
