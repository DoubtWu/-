package com.mojang.tower;
// Download by http://www.codefans.net
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.VolatileImage;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class TowerComponent extends Canvas
  implements Runnable, MouseListener, MouseMotionListener
{
  public static final int TICKS_PER_SECOND = 30;
  private static final int MAX_TICKS_PER_FRAME = 10;
  private static final long serialVersionUID = 1L;
  private boolean running;
  private int width;
  private int height;
  private VolatileImage image;
  private Thread thread;
  private int tickCount;
  private int frames;
  private boolean paused;
  private int xMouse = -1;
  private int yMouse;
  private double xRot;
  private double xRotA;
  Bitmaps bitmaps = new Bitmaps();
  private Island island;
  private boolean scrolling = false;
  private double xScrollStart;
  private int xCenter;
  private int yCenter;
  private int selectedHouseType = 0;
  private boolean titleScreen = true; private boolean won = false;
  private int gameTime = 0; private int winScore = 0;
  private int wonTime;

  public TowerComponent(int width, int height)
  {
	  
    this.width = width;
    this.height = height;
    setSize(width * 2, height * 2);
    addMouseMotionListener(this);
    addMouseListener(this);

    this.xCenter = (width / 2);
    this.yCenter = (height * 43 / 70);
  }

  public void unpause()
  {
    if (this.thread == null)
    {
      start();
    }
    this.paused = false;
  }

  public void pause()
  {
    this.paused = true;
  }

  public void paint(Graphics g)
  {
  }

  public void update(Graphics g)
  {
  }

  public void start()
  {
    this.thread = new Thread(this);
    this.thread.start();
  }

  public void stop()
  {
    this.running = false;
    try
    {
      if (this.thread != null) this.thread.join();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
  }

  private void init()
  {
    try
    {
      this.bitmaps.loadAll();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }

    this.island = new Island(this, this.bitmaps.island);
  }

  public void run()
  {
    init();
    float lastTime = (float)(System.nanoTime() / 1000000L) / 1000.0F;
    this.running = true;

    double msPerTick = 0.03333333333333333D;

    while (this.running)
    {
      synchronized (this)
      {
        float now = (float)(System.nanoTime() / 1000000L) / 1000.0F;
        int frameTicks = 0;
        while (now - lastTime > msPerTick)
        {
          if ((!this.paused) && (frameTicks++ < 10)) tick();

          lastTime = (float)(lastTime + msPerTick);
        }

        if (!this.paused)
        {
          render((now - lastTime) / msPerTick);
        }
      }

      try
      {
        Thread.sleep(this.paused ? 200 : 4);
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
    }
  }

  private void tick()
  {
    if (this.won) this.wonTime += 1;
    this.xRot += this.xRotA;
    this.xRotA *= 0.7D;

    if ((this.titleScreen) || (this.won))
    {
      this.xRotA -= 0.002D;
    }
    else if (this.scrolling)
    {
      double xd = this.xMouse - this.xScrollStart;
      this.xRotA -= xd / 10000.0D;
    }
    else if ((this.xMouse >= 0) && (this.yMouse < this.height * 2 - 40) && (this.yMouse > 80))
    {
      if (this.xMouse < 80) this.xRotA += 0.02D;
      if (this.xMouse > this.width * 2 - 80) this.xRotA -= 0.02D;

    }

    this.island.rot = this.xRot;

    this.tickCount += 1;
    if (this.tickCount % 30 == 0)
    {
      this.frames = 0;
    }

    if ((!this.titleScreen) && (!this.won))
    {
      this.gameTime += 1;
    }
    if (!this.titleScreen) this.island.tick();
  }

  private void render(double alpha)
  {
    this.frames += 1;
    BufferStrategy bs = getBufferStrategy();
    if (bs == null)
    {
      createBufferStrategy(2);
      bs = getBufferStrategy();
    }

    if (this.image == null)
    {
      this.image = createVolatileImage(this.width, this.height);
    }

    if (bs != null)
    {
      Graphics2D g = this.image.createGraphics();
      renderGame(g, alpha);
      g.dispose();

      Graphics gg = bs.getDrawGraphics();
      gg.drawImage(this.image, 0, 0, this.width * 2, this.height * 2, 0, 0, this.width, this.height, null);
      gg.dispose();
      bs.show();
    }
  }

  private void renderGame(Graphics2D g, double alpha)
  {
    int seconds = this.gameTime / 30;
    int minutes = seconds / 60;
    int hours = minutes / 60;
    seconds %= 60;
    minutes %= 60;

    String timeStr = "";
    if (hours > 0)
    {
      timeStr = timeStr + hours + ":";
      if (minutes < 10) timeStr = timeStr + "0";
    }
    timeStr = timeStr + minutes + ":";
    if (seconds < 10) timeStr = timeStr + "0";
    timeStr = timeStr + seconds;

    g.setColor(new Color(4422071));
    g.fillRect(0, 0, this.width, this.height);

    if ((!this.titleScreen) && (!this.won))
    {
      g.setColor(new Color(8891903));
      g.fillRect(0, 0, this.width, 40);
    }

    double rot = this.xRot + this.xRotA * alpha;
    double sin = Math.sin(rot);
    double cos = Math.cos(rot);

    for (int i = 0; i < this.island.entities.size(); i++)
    {
      Entity e = (Entity)this.island.entities.get(i);
      e.updatePos(sin, cos, alpha);
    }

    Collections.sort(this.island.entities);

    AffineTransform af = g.getTransform();
    g.translate(this.xCenter, this.yCenter);
    g.scale(1.5D, 1.5D);
    g.scale(1.0D, 0.5D);
    g.rotate(-rot);
    g.translate(-128, -128);
    g.drawImage(this.bitmaps.island, 0, 0, null);
    g.setTransform(af);

    g.translate(this.xCenter, this.yCenter);

    for (int i = 0; i < this.island.entities.size(); i++) {
      ((Entity)this.island.entities.get(i)).render(g, alpha);
    }
    if ((!this.titleScreen) && (!this.won))
    {
      if (this.selectedHouseType >= 0)
      {
        boolean canPlace = this.island.canPlaceHouse(this.xMouse - this.xCenter * 2, this.yMouse - this.yCenter * 2, HouseType.houseTypes[this.selectedHouseType]);
        if (canPlace)
        {
          g.drawImage(HouseType.houseTypes[this.selectedHouseType].getImage(this.bitmaps), this.xMouse / 2 - this.xCenter - 8, this.yMouse / 2 - this.yCenter - 11, null);
        }
      }
      else
      {
        Entity e = this.island.getEntityAtMouse(this.xMouse - this.xCenter * 2, this.yMouse - this.yCenter * 2 + 3, new TargetFilter()
        {
          public boolean accepts(Entity e)
          {
            return e instanceof House;
          }
        });
        if (e != null)
        {
          g.drawImage(this.bitmaps.delete, this.xMouse / 2 - this.xCenter - 8, this.yMouse / 2 - this.yCenter - 11, null);
        }
      }
    }

    g.setTransform(af);
    g.setFont(new Font("Sans-Serif", 0, 10));

    if (this.titleScreen)
    {
      g.drawImage(this.bitmaps.logo, (this.width - this.bitmaps.logo.getWidth()) / 2, 16, null);

      FontMetrics fm = g.getFontMetrics();
      g.setColor(new Color(0));
      for (int i = 0; i < 2; i++)
      {
        if (this.tickCount / 10 % 2 == 0)
        {
          String str = "Click to start the game";
          g.drawString(str, (this.width - fm.stringWidth(str)) / 2 - i, this.height - 16 - i);
        }

        g.setColor(new Color(16777215));
      }
    }
    else if (this.won)
    {
      g.drawImage(this.bitmaps.wonScreen, (this.width - this.bitmaps.logo.getWidth()) / 2, 16, null);
      FontMetrics fm = g.getFontMetrics();
      g.setColor(new Color(0));
      for (int i = 0; i < 2; i++)
      {
        if (i == 1) g.setColor(new Color(16776960));
        String str = "Time: " + timeStr + ", Score: " + this.winScore;
        g.drawString(str, (this.width - fm.stringWidth(str)) / 2 - i, this.height * 45 / 100 - i);

        if (i == 1) g.setColor(new Color(16777215));
        if ((this.wonTime < 90) || (this.tickCount / 10 % 2 != 0))
          continue;
        str = "Click to continue playing";
        g.drawString(str, (this.width - fm.stringWidth(str)) / 2 - i, this.height - 16 - i);
      }

    }
    else
    {
      for (int i = -1; i < HouseType.houseTypes.length; i++)
      {
        int x = i * 20 + (this.width - (HouseType.houseTypes.length + 1) * 20) / 2;
        int y = 4;
        if (i == -1)
        {
          g.drawImage(this.bitmaps.delete, x, y, null);
        }
        else
        {
          g.drawImage(HouseType.houseTypes[i].getImage(this.bitmaps), x, y, null);
        }
        if (i != this.selectedHouseType)
          continue;
        g.setColor(Color.WHITE);
        g.drawRect(x - 2, y - 2, 19, 19);
      }

      FontMetrics fm = g.getFontMetrics();
      g.setColor(new Color(4685199));
      for (int i = 0; i < 2; i++)
      {
        int x = this.selectedHouseType * 20 + (this.width - (HouseType.houseTypes.length + 1) * 20) / 2;
        int y = 32;

        if (this.selectedHouseType >= 0)
        {
          HouseType ht = HouseType.houseTypes[this.selectedHouseType];

          String s = ht.getString();
          g.drawString(s, x + 8 - fm.stringWidth(s) / 2 - i, y - i);
          s = ht.getDescription();
          g.drawString(s, x + 8 - fm.stringWidth(s) / 2 - i, y - i + 11);
        }
        else
        {
          String s = "Sell building";
          g.drawString(s, x + 8 - fm.stringWidth(s) / 2 - i, y - i);
          s = "Returns 75% of wood and rock used";
          g.drawString(s, x + 8 - fm.stringWidth(s) / 2 - i, y - i + 11);
        }

        String tmp = "Wood: 9999";
        g.drawString("Wood: " + this.island.resources.wood, this.width - 4 - i - fm.stringWidth(tmp), 12 - i + 0);
        g.drawString("Rock: " + this.island.resources.rock, this.width - 4 - i - fm.stringWidth(tmp), 12 - i + 11);
        g.drawString("Food: " + this.island.resources.food, this.width - 4 - i - fm.stringWidth(tmp), 12 - i + 22);

        String pop = "Population: " + this.island.population + " / " + this.island.populationCap;
        g.drawString(pop, 4 - i, 12 - i + 11);
        pop = "Warriors: " + this.island.warriorPopulation + " / " + this.island.warriorPopulationCap;
        g.drawString(pop, 4 - i, 12 - i + 22);

        g.drawString("Time: " + timeStr, 4 - i, 12 - i + 0);
        g.setColor(Color.WHITE);
      }
    }

    g.drawImage(this.bitmaps.soundButtons[0], this.width - 20, this.height - 20, null);
  }

  public void mouseClicked(MouseEvent me)
  {
  }

  public void mouseEntered(MouseEvent me)
  {
  }

  public void mouseExited(MouseEvent me)
  {
    this.xMouse = -1;
  }

  public void mousePressed(MouseEvent me)
  {
    synchronized (this)
    {
      if ((me.getX() >= this.width * 2 - 40) && (me.getY() >= this.height * 2 - 40) && (me.getX() <= this.width * 2 - 40 + 32) && (me.getY() <= this.height * 2 - 40 + 32))
      {
        Sounds.setMute(!Sounds.isMute());
        return;
      }

      if (this.titleScreen)
      {
        this.titleScreen = false;
        return;
      }
      if (this.won)
      {
        if (this.wonTime >= 90)
        {
          this.won = false;
        }
        return;
      }
      if (me.getButton() == 1)
      {
        int xm = me.getX() / 2;
        int ym = me.getY() / 2;
        for (int i = -1; i < HouseType.houseTypes.length; i++)
        {
          int x = i * 20 + (this.width - (HouseType.houseTypes.length + 1) * 20) / 2;
          int y = 4;

          if ((xm < x - 2) || (ym < y - 2) || (xm >= x + 18) || (ym >= y + 18))
            continue;
          if (this.selectedHouseType == i)
            continue;
          this.selectedHouseType = i;
          Sounds.play(new Sound.Select());
        }

        if (this.selectedHouseType >= 0)
        {
          this.island.placeHouse(me.getX() - this.xCenter * 2, me.getY() - this.yCenter * 2, HouseType.houseTypes[this.selectedHouseType]);
        }
        else
        {
          Entity e = this.island.getEntityAtMouse(this.xMouse - this.xCenter * 2, this.yMouse - this.yCenter * 2 + 3, new TargetFilter()
          {
            public boolean accepts(Entity e)
            {
              return e instanceof House;
            }
          });
          if (e != null)
          {
            ((House)e).sell();
          }
        }
      }
      if (me.getButton() == 3)
      {
        this.xScrollStart = me.getX();
        this.scrolling = true;
      }
    }
  }

  public void mouseReleased(MouseEvent me)
  {
    if (me.getButton() == 3)
    {
      this.scrolling = false;
    }
  }

  public void mouseDragged(MouseEvent me)
  {
    this.xMouse = me.getX();
    this.yMouse = me.getY();
  }

  public void mouseMoved(MouseEvent me)
  {
    this.xMouse = me.getX();
    this.yMouse = me.getY();
  }


  public static void main(String args[])
  {
      final TowerComponent tower = new TowerComponent(512, 320);
      Frame frame = new Frame("1704070137 软件工程一班 吴衡");
      frame.add(tower);
      frame.pack();
      frame.setLocationRelativeTo(null);
      frame.setResizable(false);
      frame.addWindowListener(new WindowAdapter() {

          public void windowClosing(WindowEvent we)
          {
              tower.stop();
              System.exit(0);
          }

      }
);
      frame.setVisible(true);
      tower.start();
      new Music();
  }
  public void win()
  {
    this.won = true;
    this.winScore = (1105032704 / this.gameTime);
  }
}