// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Monster.java

package com.mojang.tower;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

// Referenced classes of package com.mojang.tower:
//            Entity, Island, Sounds, House, 
//            Peon, Bitmaps, Sound, TargetFilter

public class Monster extends Entity
{

    public Monster(double x, double y)
    {
        super(x, y, 2D);
        rot = 0.0D;
        moveTick = 0.0D;
        wanderTime = 0;
        hp = 100;
        maxHp = 100;
        rot = random.nextDouble() * 3.1415926535897931D * 2D;
        moveTick = random.nextInt(12);
    }

    public void init(Island island, Bitmaps bitmaps)
    {
        super.init(island, bitmaps);
        island.monsterPopulation++;
    }

    public void die()
    {
        Sounds.play(new Sound.MonsterDeath());
        island.monsterPopulation--;
        alive = false;
    }

    public void tick()
    {
        if(hp < maxHp && random.nextInt(16) == 0)
            hp++;
        if(target == null || random.nextInt(100) == 0)
        {
            Entity e = getRandomTarget(60D, 30D, new TargetFilter() {

                public boolean accepts(Entity e)
                {
                    return e.isAlive() && ((e instanceof House) || (e instanceof Peon));
                }

            }
);
            if((e instanceof House) || (e instanceof Peon))
                target = e;
        }
        if(target != null && !target.isAlive())
            target = null;
        double speed = 1.0D;
        if(wanderTime == 0 && target != null)
        {
            double xd = target.x - x;
            double yd = target.y - y;
            double rd = target.r + r + 2D;
            if(xd * xd + yd * yd < rd * rd)
            {
                speed = 0.0D;
                target.fight(this);
            }
            rot = Math.atan2(yd, xd);
        } else
        {
            rot += (random.nextDouble() - 0.5D) * random.nextDouble();
        }
        if(wanderTime > 0)
            wanderTime--;
        double xt = x + Math.cos(rot) * 0.29999999999999999D * speed;
        double yt = y + Math.sin(rot) * 0.29999999999999999D * speed;
        if(island.isFree(xt, yt, r, this))
        {
            x = xt;
            y = yt;
        } else
        {
            rot += ((double)(random.nextInt(2) * 2) - 1.5707963267948966D) + (random.nextDouble() - 0.5D);
            wanderTime = random.nextInt(30);
        }
        moveTick += speed;
        super.tick();
    }

    public void render(Graphics2D g, double alpha)
    {
        int rotStep = (int)Math.floor(((rot - island.rot) * 4D) / 6.2831853071795862D + 0.5D);
        int animStep = animSteps[(int)(moveTick / 4D) & 3];
        int x = (int)(xr - 4D);
        int y = -(int)(yr / 2D + 8D);
        g.drawImage(bitmaps.peons[3][animDirs[rotStep & 3] * 3 + animStep], x, y, null);
        if(hp < maxHp)
        {
            g.setColor(Color.BLACK);
            g.fillRect(x + 2, y - 2, 4, 1);
            g.setColor(Color.RED);
            g.fillRect(x + 2, y - 2, (hp * 4) / maxHp, 1);
        }
    }

    public void fight(Peon peon)
    {
        if(hp <= 0)
            return;
        if(random.nextInt(5) == 0)
            target = peon;
        if(--hp <= 0)
        {
            die();
            peon.addXp();
        }
    }

    private static final int animSteps[] = {
        0, 1, 0, 2
    };
    private static final int animDirs[] = {
        2, 0, 3, 1
    };
    public double rot;
    public double moveTick;
    private int wanderTime;
    protected Entity target;
    private int hp;
    private int maxHp;

}
