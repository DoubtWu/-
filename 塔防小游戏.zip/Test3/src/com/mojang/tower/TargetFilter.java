// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TargetFilter.java

package com.mojang.tower;


// Referenced classes of package com.mojang.tower:
//            Entity

public class TargetFilter
{

    public TargetFilter()
    {
    }

    public boolean accepts(Entity e)
    {
        return true;
    }
}
